# Scenes folder

## Introduction
This folder is generated automatically by the editor. This will containg all the scene's scripts attached to objects.
