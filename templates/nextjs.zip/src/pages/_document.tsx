import Document, { Head, Html, Main, NextScript } from "next/document";

export default class RootDocument extends Document {
	/**
	 * Renders the component.
	 */
	public render(): JSX.Element {
		return (
			<Html lang="en">
				<Head>
					
				</Head>

				<body>
					<Main />
					<NextScript />
				</body>
			</Html>
		);
	}
}
