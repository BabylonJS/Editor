import { ScriptMap } from "./tools";

/**
 * Defines the interface that exposes all exported scripts in this project.
 */
export interface ISceneScriptMap extends ScriptMap {
	"src/scenes/_graphs/graphs_launchBall.graph.ts": any;
	"src/scenes/_graphs/graphs_pointerLock.graph.ts": any;
	"src/scenes/scene/camera.ts": any;
}

/**
 * Defines the map of all available scripts in the project.
 */
export const scriptsMap: ISceneScriptMap = {
	"src/scenes/_graphs/graphs_launchBall.graph.ts": require("./_graphs/graphs_launchBall.graph"),
	"src/scenes/_graphs/graphs_pointerLock.graph.ts": require("./_graphs/graphs_pointerLock.graph"),
	"src/scenes/scene/camera.ts": require("./scene/camera"),
}
