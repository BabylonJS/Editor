import { AppProps } from "next/app";

import "../css/globals.css";

export default function RootApp(props: AppProps) {
	return (
		<div className="w-screen h-screen">
			<props.Component {...props} />
		</div>
	);
}
