import { useEffect, useRef } from "react";

import { Scene } from "@babylonjs/core/scene";
import { Engine } from "@babylonjs/core/Engines/engine";

import "@babylonjs/core/Loading/loadingScreen";
import "@babylonjs/core/Loading/Plugins/babylonFileLoader";

import "@babylonjs/core/Meshes/groundMesh";

import "@babylonjs/core/Materials/PBR/pbrMaterial";
import "@babylonjs/core/Materials/standardMaterial";

import "@babylonjs/core/Rendering/prePassRendererSceneComponent";

import "@babylonjs/core/Lights/directionalLight";
import "@babylonjs/core/Lights/Shadows/shadowGeneratorSceneComponent";

import "@babylonjs/core/Cameras/universalCamera";

import "@babylonjs/materials/sky";

import { appendScene } from "@/scenes/tools";

export default function Index() {
	const canvasRef = useRef<HTMLCanvasElement>(null);

	useEffect(() => {
		if (!canvasRef.current) {
			return;
		}

		const engine = new Engine(canvasRef.current, true, {
			alpha: false,
			antialias: true,
			adaptToDeviceRatio: true,
			disableWebGL2Support: false,
			useHighPrecisionFloats: true,
			useHighPrecisionMatrix: true,
			powerPreference: "high-performance",
		});

		const scene = new Scene(engine);

		appendScene(scene, "/scenes/_assets/", "../scene/scene.babylon").then(() => {
			scene.executeWhenReady(() => {
				scene.activeCamera?.attachControl();

				engine.runRenderLoop(() => {
					scene.render();
				});
			});
		});

		let resizeListener: () => void;
		window.addEventListener("resize", () => {
			engine.resize();
		});

		return () => {
			scene.dispose();
			engine.dispose();

			window.removeEventListener("resize", resizeListener);
		};
	}, [canvasRef.current]);

	return (
		<main className="w-screen h-screen">
			<canvas
				ref={canvasRef}
				className="w-full h-full bg-black"
			/>
		</main>
	);
}
